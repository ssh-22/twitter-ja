$(window).on('load', function(){
    $('img#profile.lazyload').lazyload();
    $('a strong').css({
        color: 'initial',
    });
});